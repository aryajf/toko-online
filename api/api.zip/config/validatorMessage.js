module.exports = {
    messages : {
        stringEmpty : '{field} wajib diisi',
        string : '{field} harus berupa huruf',
        number : '{field} nilai harus berisi bilangan',
        numberMin : '{field} minimal angka {expected}',
        numberInteger : '{field} nilai harus berisi bilangan bulat',
        numberPositive : '{field} nilai harus berisi bilangan positif',
        stringMin : '{field} minimal {expected} huruf',
        required : '{field} wajib diisi'
    }
}